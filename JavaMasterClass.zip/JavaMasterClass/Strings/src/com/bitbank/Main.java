package com.bitbank;

public class Main {

    public static void main(String[] args) {
	// String Types

        double dNumberOne = 20d;
        double dNumberTwo = 80d;

        double addResult = (dNumberOne + dNumberTwo) * 25;

        System.out.println(addResult % 40);

        if(addResult % 40 <= 20){
            System.out.println("Total Was over the Limit...");
        }
    }
}
