package com.bitbank;

public class Main {

    public static void main(String[] args) {

	// Convert a given number of pounds to Kilograms

      double weightInPounds = 95d;
      double totalKilos = weightInPounds * 0.45359237d;

        System.out.println(totalKilos);

    }
}
