package com.bitbank;

public class Main {

    public static void main(String[] args) {
	// Char and Booleans
        char myChar = '\u00AE';

        System.out.println(myChar);

    }
}
