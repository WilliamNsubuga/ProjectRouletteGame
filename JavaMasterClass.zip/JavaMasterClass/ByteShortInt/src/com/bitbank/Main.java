package com.bitbank;

public class Main {

    public static void main(String[] args) {

        byte myByte = 10;
        short myShort = 20;
        int myValue = 50;
        long myTotal = (5000l + 10 * (myByte + myShort + myValue));
        System.out.println(myTotal);

    }
}
