package com.bitbank;

public class Main {

    public static void main(String[] args) {
        // write your code here
        double miles = 1.609344d;
        double kilometres = (100 * miles);

        int highScore = 50;

        if (highScore == 50){System.out.println("HighScore");}

        System.out.println(Math.round(kilometres));

        int myVariable = 50;
        myVariable++;
        myVariable += 100;

        myVariable--;

        myVariable++;

        System.out.println(myVariable);

        System.out.println("This is text" +
                " continuing.. " +
                miles);


    }
}
