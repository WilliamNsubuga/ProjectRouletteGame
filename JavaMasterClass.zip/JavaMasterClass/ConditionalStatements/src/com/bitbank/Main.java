package com.bitbank;

public class Main {

    public static void main(String[] args) {
	// write your code here

        boolean gameOver = false;
        int score = 10000;
        int levelCompleted = 8;
        int bonues = 200;

        if(score < 5000 && score > 1000) {
            System.out.println("Your Score was greater than 1000 but less than 5000");
        }else{
            System.out.println("Hi..." + levelCompleted);
        }

    }
}
